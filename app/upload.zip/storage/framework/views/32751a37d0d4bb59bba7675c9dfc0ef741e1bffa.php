<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <div class="panel panel-default">
        <div class="panel-heading"><h3>Edite o produto</h3></div>
        <div class="panel-body">
            <form method="post" action="<?php echo e(route ('produtos.update', $produto->id)); ?>">
                <input type="hidden" name="_method" value="PUT">
                <?php echo e(csrf_field()); ?>

                <h4>Dados do produto</h4>
                <hr>
                <div class="form-group">
                    <label for="descricao">Descrição</label>
                    <input type="text" class="form-control" placeholder="Descrição" name="descricao" required value="<?php echo e($produto->descricao); ?>">
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="preco">Preço</label>
                            <input type="text" class="form-control" placeholder="Preço" name="preco" required value="<?php echo e($produto->preco); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="qtdQuartos">Cor</label>
                            <input type="text" class="form-control" placeholder="Cor" required name="cor"value="<?php echo e($produto->cor); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="qtdQuartos">Peso</label>
                            <input type="text" class="form-control" placeholder="Peso" required name="peso" value="<?php echo e($produto->peso); ?>">
                        </div>
                    </div>
                </div>
                <h4>Marca</h4>
                <hr>
                <div class="form-group">
                    <label for="marca_id">Selecione a marca deste produto</label>
                    <select class="form-control" name="marca_id" required>
                        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($marca->id); ?>"
                                <?php echo e((isset($produto->marca_id) && $produto->marca_id == $marca->id ?
                                'selected' : '')); ?>><?php echo e($marca->nome); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Voltar</a>
                <button type="submit" class="btn btn-primary">Editar</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/produtos/edit.blade.php ENDPATH**/ ?>