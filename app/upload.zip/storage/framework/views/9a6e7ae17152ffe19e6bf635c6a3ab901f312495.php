<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="panel panel-default">
            <!-- Default panel contents -->
            <div class="panel-heading">Detalhes do imóvel</div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        <h4>Sobre a marca</h4>
                        <p>Nome: <?php echo e($marca->nome); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Voltar</a>
        </div>
    </div>

<?php echo $__env->make('shared.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/marcas/show.blade.php ENDPATH**/ ?>