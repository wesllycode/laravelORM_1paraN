<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <div class="panel panel-default">
        <div class="panel-heading"><h3>Edite a marca</h3></div>
        <div class="panel-body">
            <form method="post" action="<?php echo e(route ('marcas.update', $marca->id)); ?>">
                <input type="hidden" name="_method" value="PUT">
                <?php echo e(csrf_field()); ?>

                <h4>Dados do marca</h4>
                <hr>
                <div class="form-group">
                    <label for="descricao">Nome</label>
                    <input type="text" class="form-control" placeholder="Nome" name="nome" required value="<?php echo e($marca->nome); ?>">
                </div>
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Voltar</a>
                <button type="submit" class="btn btn-primary">Editar</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/marcas/edit.blade.php ENDPATH**/ ?>