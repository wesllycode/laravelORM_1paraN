<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <div class="panel-heading">Lista de Marcas</div>
        <form method="GET" action="<?php echo e(route('marcas.index', 'buscar' )); ?>">
            <div class="row">
                <div class="col-md-12">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Digite o nome da marca" name="buscar">
                        <span class="input-group-btn">
                        <button class="btn btn-default" type="submit">Pesquisar</button>
                    </span>
                    </div>
                </div>
            </div>
        </form>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Produtos</th>
                        <th>Ações</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($marca->nome); ?></td>
                            <td><a href="<?php echo e(route('marcas.produtos', $marca->id)); ?>">Listar Produtos</a></td>
                            <td>
                                <a href="<?php echo e(route('marcas.edit', $marca->id)); ?>"><i class="glyphicon glyphicon-pencil"></i></a>
                                <a href="<?php echo e(route('marcas.remove', $marca->id)); ?>"><i class="glyphicon glyphicon-trash"></i></a>
                                <a href="<?php echo e(route('marcas.show', $marca->id)); ?>"><i class="glyphicon glyphicon-zoom-in"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div align="center" class="row">
            <?php echo e($marcas->links()); ?>

        </div>
    </div>
    <a href="<?php echo e(route('marcas.create')); ?>"><button class="btn btn-primary">Adicionar</button></a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/marcas/index.blade.php ENDPATH**/ ?>